# 📧 Sistema de Notificaciones por Email - SUPERMAX Catering

Sistema completo de notificaciones automáticas por email para el sistema de pedidos e-commerce.

## ✅ Características Implementadas

### 📩 Emails Automáticos

1. **Pedido Recibido** (Estado: Pendiente)
   - Se envía cuando el cliente crea la orden
   - Incluye resumen completo del pedido
   - Estado: Pendiente de pago
   - Alerta sobre confirmación posterior

2. **Pago Confirmado** (Estado: Aprobado)
   - Se envía cuando MercadoPago aprueba el pago
   - Confirmación de pago exitoso
   - Detalles completos del pedido
   - Información de entrega
   - Políticas de cancelación

### 🎨 Diseño de Emails

- Responsive (se adapta a móvil y desktop)
- Colores corporativos (Rojo #d81d25, Amarillo #ffd90f)
- Tabla de productos con precios
- Badges de estado visuales
- Información de contacto completa
- Llamados a la acción (CTAs)

### ⚙️ Tecnología

- **Laravel Mail System**
- **Queue Jobs** (procesamiento asíncrono)
- **SMTP Outlook** (configuración incluida)
- **Blade Templates** (vistas HTML)

## 🚀 Configuración Rápida

### 1. Configurar Outlook en .env

```env
MAIL_MAILER=smtp
MAIL_HOST=smtp-mail.outlook.com
MAIL_PORT=587
MAIL_USERNAME=tu-email@outlook.com
MAIL_PASSWORD=tu-contraseña
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="tu-email@outlook.com"
MAIL_FROM_NAME="SUPERMAX Catering"
```

**⚠️ Si usas autenticación de dos factores:**
1. Ve a https://account.microsoft.com/security
2. Crea una "Contraseña de aplicación"
3. Úsala en `MAIL_PASSWORD`

### 2. Verificar cola de trabajos

```env
QUEUE_CONNECTION=database
```

### 3. Iniciar el worker

```bash
# En desarrollo (mantener terminal abierta)
php artisan queue:work

# En producción
php artisan queue:work --tries=3 --timeout=90
```

## 🧪 Probar Emails

### Enviar email de prueba

```bash
# Email de pedido creado (pendiente)
php artisan email:test created

# Email de pago confirmado (aprobado)
php artisan email:test approved

# Especificar una orden por ID
php artisan email:test created --order=5
```

### Probar en la aplicación

1. Agrega productos al carrito
2. Completa el checkout con un email real
3. Verifica tu bandeja de entrada
4. Completa el pago en MercadoPago
5. Verifica el segundo email de confirmación

## 📁 Archivos del Sistema

### Mailables
- `app/Mail/OrderCreated.php` - Email de pedido creado
- `app/Mail/OrderApproved.php` - Email de pago confirmado

### Jobs (Cola de trabajos)
- `app/Jobs/SendOrderCreatedEmail.php` - Encolar email de pedido creado
- `app/Jobs/SendOrderApprovedEmail.php` - Encolar email de pago aprobado

### Vistas de Emails
- `resources/views/emails/order-created.blade.php` - Vista HTML pedido creado
- `resources/views/emails/order-approved.blade.php` - Vista HTML pago confirmado

### Controladores
- `app/Http/Controllers/MercadoPagoController.php` - Despacha los jobs

### Comandos
- `app/Console/Commands/TestEmailCommand.php` - Comando para pruebas

## 🔧 Comandos Útiles

```bash
# Ver trabajos en cola
php artisan queue:monitor

# Reintentar trabajos fallidos
php artisan queue:retry all

# Limpiar trabajos fallidos
php artisan queue:flush

# Reiniciar worker
php artisan queue:restart

# Ver logs en tiempo real
Get-Content storage\logs\laravel.log -Tail 50 -Wait
```

## 🐛 Solución de Problemas

### Los emails no se envían

1. **Verifica que el worker esté corriendo**
   ```bash
   php artisan queue:work
   ```

2. **Revisa los logs**
   ```bash
   Get-Content storage\logs\laravel.log -Tail 100
   ```

3. **Verifica credenciales en .env**
   - Usuario y contraseña correctos
   - Si usas 2FA, usa contraseña de aplicación

4. **Verifica la tabla jobs**
   ```bash
   php artisan tinker
   DB::table('jobs')->count()
   ```

### Error de autenticación SMTP

- Verifica usuario y contraseña
- Si usas 2FA, genera contraseña de aplicación
- Verifica que el correo de Outlook esté activo
- Prueba con otro cliente de email primero

### Los emails van a spam

- Configura `MAIL_FROM_ADDRESS` con un email válido de Outlook
- Evita palabras "spam" en el asunto
- En producción, configura SPF y DKIM

## 📊 Flujo de Envío de Emails

```
1. Cliente crea pedido
   └─> MercadoPagoController::createPreference()
       └─> Se crea la orden
           └─> SendOrderCreatedEmail::dispatch($order)
               └─> Email "Pedido Recibido" en cola

2. Cliente completa pago en MercadoPago
   └─> MercadoPago envía webhook
       └─> MercadoPagoController::webhook()
           └─> Se actualiza estado de orden a "paid"
               └─> SendOrderApprovedEmail::dispatch($order)
                   └─> Email "Pago Confirmado" en cola

3. Worker procesa emails
   └─> php artisan queue:work
       └─> Procesa jobs pendientes
           └─> Envía emails vía SMTP Outlook
```

## 🔐 Seguridad

- Los emails se envían desde cola (background)
- No bloquea la experiencia del usuario
- Reintentos automáticos en caso de fallo
- Logs completos de todos los envíos
- Credenciales seguras en .env

## 📈 Producción

### Supervisor (Linux)

Crea `/etc/supervisor/conf.d/laravel-worker.conf`:

```ini
[program:laravel-worker]
process_name=%(program_name)s_%(process_num)02d
command=php /ruta/proyecto/artisan queue:work --sleep=3 --tries=3 --max-time=3600
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
user=www-data
numprocs=1
redirect_stderr=true
stdout_logfile=/ruta/proyecto/storage/logs/worker.log
stopwaitsecs=3600
```

```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start laravel-worker:*
```

### Windows (Tarea Programada)

1. Abre Programador de tareas
2. Crea nueva tarea
3. Ejecuta: `php C:\ruta\proyecto\artisan queue:work`
4. Configura para iniciar al arrancar el sistema
5. Reiniciar si falla

## 📝 Personalización

### Cambiar diseño de emails

Edita las vistas:
- `resources/views/emails/order-created.blade.php`
- `resources/views/emails/order-approved.blade.php`

### Agregar nuevo tipo de email

1. Crear Mailable: `php artisan make:mail NuevoEmail`
2. Crear Job: `php artisan make:job SendNuevoEmail`
3. Crear vista: `resources/views/emails/nuevo-email.blade.php`
4. Despachar job donde corresponda

## ✨ Mejoras Futuras

- [ ] Email de pedido despachado
- [ ] Email de pedido entregado
- [ ] Email de cancelación
- [ ] Email recordatorio 24h antes de entrega
- [ ] Email de feedback post-entrega
- [ ] Newsletter de ofertas
- [ ] Email de carrito abandonado

## 📞 Soporte

Para consultas sobre el sistema de emails:
- Revisa `CONFIGURACION-EMAILS.md` para guía detallada
- Ejecuta `php artisan email:test` para pruebas
- Revisa logs en `storage/logs/laravel.log`

---

**Desarrollado para SUPERMAX S.A. - Catering E-commerce**
