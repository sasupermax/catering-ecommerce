# Configuración de Emails con Outlook

## Paso 1: Configurar las credenciales en el archivo .env

Abre el archivo `.env` y configura las siguientes variables con tus datos de Outlook:

```env
MAIL_MAILER=smtp
MAIL_HOST=smtp-mail.outlook.com
MAIL_PORT=587
MAIL_USERNAME=tu-email@outlook.com
MAIL_PASSWORD=tu-contraseña
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="tu-email@outlook.com"
MAIL_FROM_NAME="SUPERMAX Catering"
```

**Importante:** Si usas autenticación de dos factores en Outlook, necesitarás crear una **contraseña de aplicación**:

1. Ve a https://account.microsoft.com/security
2. Haz clic en "Opciones de seguridad avanzadas"
3. En "Contraseñas de aplicación", crea una nueva
4. Usa esa contraseña en `MAIL_PASSWORD`

## Paso 2: Verificar la configuración de cola

Asegúrate de que tu archivo `.env` tenga:

```env
QUEUE_CONNECTION=database
```

## Paso 3: Ejecutar el worker de colas

Para procesar los emails, necesitas ejecutar el worker de Laravel:

### En desarrollo (ventana de terminal):
```bash
php artisan queue:work
```

### En producción (mantener corriendo con supervisor o similar):
```bash
php artisan queue:work --tries=3 --timeout=90
```

**Nota:** Mantén esta ventana abierta mientras trabajas en desarrollo. Los emails se enviarán automáticamente en segundo plano.

## Paso 4: Probar el envío de emails

### Opción 1: Crear un pedido de prueba
1. Agrega productos al carrito
2. Completa el checkout
3. Verifica que se envíe el email de "Pedido Recibido"
4. Completa el pago en MercadoPago
5. Verifica que se envíe el email de "Pago Confirmado"

### Opción 2: Enviar un email de prueba manualmente
Ejecuta este comando en tinker:

```bash
php artisan tinker
```

Luego ejecuta:
```php
$order = \App\Models\Order::first();
\App\Jobs\SendOrderCreatedEmail::dispatch($order);
exit
```

## Sistema de Emails Implementado

### 📧 Email 1: Pedido Recibido (Pendiente)
- **Cuándo se envía:** Cuando se crea la orden (antes de pagar)
- **Estado:** Pendiente de pago
- **Contenido:**
  - Número de pedido
  - Resumen de productos
  - Información de entrega
  - Alerta de pago pendiente

### ✅ Email 2: Pago Confirmado (Aprobado)
- **Cuándo se envía:** Cuando MercadoPago confirma el pago
- **Estado:** Pagado y confirmado
- **Contenido:**
  - Confirmación de pago exitoso
  - Número de pedido
  - Resumen de productos
  - Información de entrega
  - Fecha de pago
  - Políticas de cancelación

## Verificar logs

Si hay problemas, revisa los logs:

```bash
# Ver logs en tiempo real
Get-Content storage\logs\laravel.log -Tail 50 -Wait

# Ver últimas líneas del log
Get-Content storage\logs\laravel.log -Tail 100
```

## Comandos útiles

### Limpiar trabajos fallidos:
```bash
php artisan queue:flush
```

### Reintentar trabajos fallidos:
```bash
php artisan queue:retry all
```

### Ver trabajos en cola:
```bash
php artisan queue:monitor
```

### Detener el worker:
```bash
# Presionar Ctrl+C en la terminal donde corre queue:work
# O ejecutar:
php artisan queue:restart
```

## Solución de problemas

### Los emails no se envían
1. Verifica que el worker esté corriendo: `php artisan queue:work`
2. Revisa los logs: `storage/logs/laravel.log`
3. Verifica las credenciales en `.env`
4. Verifica que la tabla `jobs` exista en la base de datos

### Error de autenticación SMTP
1. Verifica usuario y contraseña
2. Si usas 2FA, usa una contraseña de aplicación
3. Verifica que el correo de Outlook esté activo

### Los emails van a spam
1. Verifica que `MAIL_FROM_ADDRESS` sea un email válido de Outlook
2. Configura SPF y DKIM en tu dominio (si usas dominio personalizado)
3. Evita palabras spam en el asunto

## Archivos relacionados

- `app/Mail/OrderCreated.php` - Mailable para pedido creado
- `app/Mail/OrderApproved.php` - Mailable para pedido aprobado
- `app/Jobs/SendOrderCreatedEmail.php` - Job para enviar email de pedido creado
- `app/Jobs/SendOrderApprovedEmail.php` - Job para enviar email de pedido aprobado
- `resources/views/emails/order-created.blade.php` - Vista HTML del email de pedido creado
- `resources/views/emails/order-approved.blade.php` - Vista HTML del email de pago confirmado
- `app/Http/Controllers/MercadoPagoController.php` - Despacha los jobs

## Producción

En producción, usa un gestor de procesos como Supervisor para mantener el worker corriendo:

1. Instala Supervisor
2. Crea configuración en `/etc/supervisor/conf.d/laravel-worker.conf`:

```ini
[program:laravel-worker]
process_name=%(program_name)s_%(process_num)02d
command=php /ruta/a/tu/proyecto/artisan queue:work --sleep=3 --tries=3 --max-time=3600
autostart=true
autorestart=true
stopasgroup=true
killasgroup=true
user=www-data
numprocs=1
redirect_stderr=true
stdout_logfile=/ruta/a/tu/proyecto/storage/logs/worker.log
stopwaitsecs=3600
```

3. Recarga Supervisor:
```bash
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start laravel-worker:*
```
