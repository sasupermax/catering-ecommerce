<?php
/**
 * Script para probar los headers de seguridad
 * Accede a: http://localhost:8000/test-headers.php
 */

// Incluir el autoloader de Laravel
require __DIR__.'/vendor/autoload.php';

// Bootstrap de Laravel
$app = require_once __DIR__.'/bootstrap/app.php';

// Crear una request de prueba
$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
$request = Illuminate\Http\Request::capture();
$response = $kernel->handle($request);

// Mostrar los headers
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test de Headers de Seguridad</title>
    <style>
        body { font-family: monospace; padding: 20px; background: #1e1e1e; color: #d4d4d4; }
        h1 { color: #4ec9b0; }
        .header { padding: 10px; margin: 5px 0; background: #252526; border-left: 3px solid #007acc; }
        .header-name { color: #9cdcfe; font-weight: bold; }
        .header-value { color: #ce9178; }
        .success { border-left-color: #4ec9b0; }
        .warning { border-left-color: #dcdcaa; }
        .error { border-left-color: #f48771; }
    </style>
</head>
<body>
    <h1>🔒 Headers de Seguridad Configurados</h1>
    
    <?php
    $securityHeaders = [
        'Content-Security-Policy' => 'CSP configurado',
        'X-Frame-Options' => 'Protección contra clickjacking',
        'X-Content-Type-Options' => 'Prevención de MIME sniffing',
        'Referrer-Policy' => 'Control de referrer',
        'Permissions-Policy' => 'Permisos de características',
        'Strict-Transport-Security' => 'HSTS configurado',
    ];
    
    $headersToHide = [
        'Server' => 'Header del servidor',
        'X-Powered-By' => 'Header de PHP',
    ];
    
    echo "<h2>✅ Headers de Seguridad Presentes:</h2>";
    foreach ($securityHeaders as $headerName => $description) {
        $value = $response->headers->get($headerName);
        if ($value) {
            echo "<div class='header success'>";
            echo "<span class='header-name'>{$headerName}:</span><br>";
            echo "<span class='header-value'>" . htmlspecialchars($value) . "</span><br>";
            echo "<small style='color: #6a9955;'>✓ {$description}</small>";
            echo "</div>";
        } else {
            echo "<div class='header error'>";
            echo "<span class='header-name'>{$headerName}:</span><br>";
            echo "<span style='color: #f48771;'>❌ NO CONFIGURADO</span><br>";
            echo "<small style='color: #6a9955;'>{$description}</small>";
            echo "</div>";
        }
    }
    
    echo "<h2>🚫 Headers que NO deben aparecer:</h2>";
    foreach ($headersToHide as $headerName => $description) {
        $value = $response->headers->get($headerName);
        if (!$value) {
            echo "<div class='header success'>";
            echo "<span class='header-name'>{$headerName}:</span><br>";
            echo "<span style='color: #4ec9b0;'>✓ Correctamente oculto</span><br>";
            echo "<small style='color: #6a9955;'>{$description}</small>";
            echo "</div>";
        } else {
            echo "<div class='header error'>";
            echo "<span class='header-name'>{$headerName}:</span><br>";
            echo "<span class='header-value'>" . htmlspecialchars($value) . "</span><br>";
            echo "<small style='color: #f48771;'>⚠ Este header no debería estar visible - {$description}</small>";
            echo "</div>";
        }
    }
    
    echo "<h2>📋 Configuración del Entorno:</h2>";
    echo "<div class='header warning'>";
    echo "<span class='header-name'>APP_ENV:</span> " . config('app.env') . "<br>";
    echo "<span class='header-name'>APP_URL:</span> " . config('app.url') . "<br>";
    echo "<span class='header-name'>SESSION_SECURE_COOKIE:</span> " . (config('session.secure') ? 'true' : 'false') . "<br>";
    echo "<span class='header-name'>SESSION_HTTP_ONLY:</span> " . (config('session.http_only') ? 'true' : 'false') . "<br>";
    echo "<span class='header-name'>SESSION_SAME_SITE:</span> " . config('session.same_site') . "<br>";
    echo "</div>";
    
    echo "<h2>ℹ️ Notas:</h2>";
    echo "<div class='header warning'>";
    echo "<p>• <strong>SESSION_SECURE_COOKIE=false</strong> es normal en desarrollo (HTTP)</p>";
    echo "<p>• En producción con HTTPS, estos headers funcionarán correctamente</p>";
    echo "<p>• Los headers Server y X-Powered-By se ocultan mejor en producción con Apache</p>";
    echo "</div>";
    ?>
</body>
</html>
