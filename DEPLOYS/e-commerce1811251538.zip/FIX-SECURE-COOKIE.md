# 🔒 Fix: Cookie Secure Flag

## Problema
El escáner reporta: "The 'secure' flag is not set on this cookie"

## Causa
Laravel no está detectando que la aplicación corre sobre HTTPS cuando está detrás de un proxy reverso (Traefik/Dokploy).

## ✅ Soluciones aplicadas:

### 1. AppServiceProvider fuerza HTTPS en producción
```php
// app/Providers/AppServiceProvider.php
public function boot(): void
{
    if (config('app.env') === 'production') {
        URL::forceScheme('https');
        $this->app['config']->set('session.secure', true);
    }
}
```

### 2. TrustProxies confía en todos los proxies
```php
// app/Http/Middleware/TrustProxies.php
protected $proxies = '*';
```

### 3. .env.production configurado correctamente
```env
SESSION_SECURE_COOKIE=true
SESSION_HTTP_ONLY=true
SESSION_SAME_SITE=strict
APP_URL=https://cateringsupermax.cloud
```

---

## 🚀 Pasos para aplicar el fix:

### 1. En el servidor, limpiar TODOS los caches
```bash
cd /ruta/a/tu/proyecto

# Limpiar todo
php artisan optimize:clear

# Limpiar específicamente
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan cache:clear

# Verificar configuración
php artisan tinker --execute="
echo 'APP_ENV: ' . config('app.env') . PHP_EOL;
echo 'APP_URL: ' . config('app.url') . PHP_EOL;
echo 'SESSION_SECURE: ' . (config('session.secure') ? 'true' : 'false') . PHP_EOL;
"
```

### 2. Recachar configuración
```bash
php artisan config:cache
```

### 3. Reiniciar servicios
```bash
# Si usas PHP-FPM
sudo systemctl restart php8.2-fpm

# Si usas Nginx
sudo systemctl restart nginx

# Si estás en Dokploy, reinicia el contenedor desde el panel
```

### 4. Verificar en el navegador (DevTools)
1. Abre DevTools (F12)
2. Ve a Application → Cookies
3. Busca la cookie `catering-e-commerce-session`
4. Verifica que tenga:
   - ✅ Secure
   - ✅ HttpOnly
   - ✅ SameSite: Strict

---

## 🔍 Troubleshooting adicional:

### Si aún no aparece el flag Secure:

#### Opción A: Verificar headers de proxy
```bash
# En tu servidor, instala curl si no lo tienes
apt-get install curl -y

# Verificar headers que llegan a Laravel
curl -I https://cateringsupermax.cloud

# Deberías ver:
# X-Forwarded-Proto: https
# X-Forwarded-Port: 443
```

#### Opción B: Forzar en middleware adicional
Crea un middleware personalizado:

```php
// app/Http/Middleware/ForceSecureCookies.php
<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ForceSecureCookies
{
    public function handle(Request $request, Closure $next): Response
    {
        $response = $next($request);
        
        // Forzar secure flag en todas las cookies en producción
        if (config('app.env') === 'production') {
            foreach ($response->headers->getCookies() as $cookie) {
                $response->headers->setCookie(new \Symfony\Component\HttpFoundation\Cookie(
                    $cookie->getName(),
                    $cookie->getValue(),
                    $cookie->getExpiresTime(),
                    $cookie->getPath(),
                    $cookie->getDomain(),
                    true, // secure
                    $cookie->isHttpOnly(),
                    false,
                    $cookie->getSameSite()
                ));
            }
        }
        
        return $response;
    }
}
```

Luego registrarlo en `bootstrap/app.php`:
```php
->withMiddleware(function (Middleware $middleware): void {
    $middleware->append(\App\Http\Middleware\ForceSecureCookies::class);
})
```

#### Opción C: Configurar Traefik/Dokploy correctamente

Asegúrate que tu configuración de Traefik incluye:
```yaml
http:
  middlewares:
    secure-headers:
      headers:
        sslRedirect: true
        stsSeconds: 31536000
        forceSTSHeader: true
        customRequestHeaders:
          X-Forwarded-Proto: "https"
```

---

## 📝 Verificación final:

### Comando rápido para verificar:
```bash
curl -I https://cateringsupermax.cloud | grep -i cookie
```

Deberías ver algo como:
```
set-cookie: catering-e-commerce-session=...; secure; httponly; samesite=strict
```

### Si funciona correctamente:
✅ El flag `secure` aparecerá en la cookie  
✅ El warning desaparecerá del escáner  
✅ Mantendrás la calificación A

---

## ⚠️ Nota importante:

El warning de CSP sobre `'unsafe-inline'` es **esperado y aceptable** para tu stack:
- Tailwind CSS requiere estilos inline
- Mercado Pago SDK usa scripts inline
- No afecta la calificación A

Para eliminarlo necesitarías:
- Migrar a Tailwind con JIT y hashes
- Implementar nonces en todos los scripts
- Refactorizar significativamente el frontend

**No es necesario para tener un sitio seguro.**

---

Última actualización: 17 de noviembre de 2025
