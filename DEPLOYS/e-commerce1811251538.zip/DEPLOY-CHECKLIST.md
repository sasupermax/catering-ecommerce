# ✅ Checklist de Deploy - Seguridad

## 🔒 Estado actual: Calificación A en SecurityHeaders.com

### Cambios realizados para seguridad:

#### 1. Headers de Seguridad (SecurityHeaders.php)
- ✅ Content-Security-Policy configurado
- ✅ X-Frame-Options: SAMEORIGIN
- ✅ X-Content-Type-Options: nosniff
- ✅ Referrer-Policy configurado
- ✅ Permissions-Policy configurado
- ✅ Strict-Transport-Security (HSTS)
- ✅ Headers Server y X-Powered-By eliminados

#### 2. Configuración de Cookies Seguras
- ✅ SESSION_SECURE_COOKIE=true (producción)
- ✅ SESSION_HTTP_ONLY=true
- ✅ SESSION_SAME_SITE=strict (producción)
- ✅ SESSION_DOMAIN=.cateringsupermax.cloud

#### 3. Archivos modificados
- `.env.production` - Configuración de producción
- `.env` - Configuración de desarrollo
- `config/session.php` - Valores por defecto seguros
- `app/Http/Middleware/SecurityHeaders.php` - Headers de seguridad
- `public/.htaccess` - Ocultar información del servidor
- `public/.user.ini` - Desactivar expose_php

---

## 🚀 Pasos para desplegar cambios:

### 1. Copiar archivo de producción
```bash
cp .env.production .env
```

### 2. Limpiar caches (IMPORTANTE)
```bash
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan cache:clear
php artisan optimize:clear
```

### 2.5. Verificar configuración
```bash
php artisan config:cache
php artisan tinker
>>> config('session.secure')
>>> config('app.env')
>>> config('app.url')
```

### 3. Optimizar para producción
```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### 4. Compilar assets
```bash
npm run build
```

### 5. Reiniciar servicios
```bash
# Reiniciar PHP-FPM o el servidor web
sudo systemctl restart php-fpm
sudo systemctl restart nginx
# O reiniciar desde Dokploy
```

---

## ⚠️ Warnings actuales (esperados):

### 1. CSP con 'unsafe-inline'
**Estado:** ⚠️ Warning (aceptable)  
**Razón:** Necesario para:
- Tailwind CSS (estilos inline)
- SDK de Mercado Pago
- Scripts inline de la aplicación

**Para eliminar este warning (opcional):**
- Migrar todos los scripts inline a usar nonces
- Generar hashes para estilos de Tailwind
- Esto requiere refactorización significativa del frontend

### 2. Cookie sin 'Secure' flag
**Estado:** ✅ RESUELTO  
**Configuración aplicada:**
- `SESSION_SECURE_COOKIE=true` en producción
- Requiere que el servidor use HTTPS
- Si aún aparece, verificar que PHP reconozca HTTPS correctamente

---

## 🔍 Verificación Post-Deploy:

### 1. Probar en SecurityHeaders.com
```
https://securityheaders.com/?q=cateringsupermax.cloud
```
**Resultado esperado:** Calificación A

### 2. Verificar cookies en el navegador
- Abrir DevTools → Application → Cookies
- Verificar flags: `Secure`, `HttpOnly`, `SameSite=Strict`

### 3. Probar funcionalidad
- ✅ Scripts funcionando (botones +/-, dropdowns)
- ✅ Pago de Mercado Pago redirige correctamente
- ✅ Formularios funcionan
- ✅ Imágenes cargan correctamente

---

## 📊 Calificación Actual vs Objetivo:

| Aspecto | Antes | Ahora | Objetivo |
|---------|-------|-------|----------|
| SecurityHeaders Score | F | **A** | A+ |
| X-XSS-Protection | ❌ Deprecado | ✅ Eliminado | ✅ |
| CSP | ❌ Faltaba | ✅ Configurado | ✅ |
| Cookies Seguras | ❌ Sin flags | ✅ Con flags | ✅ |
| Server Disclosure | ❌ Expuesto | ✅ Oculto | ✅ |
| Trusted Types | ❌ Faltaba | ⚠️ Solo producción | ✅ |

---

## 🎯 Mejoras futuras (opcional):

### Para lograr A+:
1. **Implementar Trusted Types**
   - Agregar políticas de Trusted Types
   - Migrar manipulación DOM a APIs seguras

2. **Eliminar 'unsafe-inline' del CSP**
   - Usar nonces para todos los scripts inline
   - Generar hashes de estilos en tiempo de compilación

3. **Agregar Subresource Integrity (SRI)**
   - Para scripts y estilos externos
   - Especialmente para Google Fonts y Mercado Pago

4. **Cookie Prefixes**
   - Usar `__Secure-` o `__Host-` prefijos en nombres de cookies
   - Requiere configuración adicional en Laravel

---

## 📝 Notas importantes:

1. **CSP en desarrollo vs producción:**
   - Desarrollo: Muy permisivo (permite todo para facilitar desarrollo)
   - Producción: Restrictivo (solo dominios necesarios)

2. **'unsafe-inline' es aceptable si:**
   - Usas un framework moderno (Laravel + Tailwind)
   - Sanitizas correctamente el input del usuario
   - No inyectas HTML sin escapar

3. **Las cookies seguras requieren HTTPS:**
   - Si el servidor no detecta HTTPS correctamente
   - Verifica la configuración de proxy reverso (Traefik)
   - Asegúrate que `TrustProxies` middleware está configurado

---

## 🆘 Troubleshooting:

### Si los scripts no funcionan después del deploy:
```bash
# Limpiar cache del navegador: Ctrl+F5
# Verificar que APP_ENV=production en .env
# Verificar errores en consola del navegador
php artisan config:clear
```

### Si las cookies no tienen flag Secure:
```bash
# Verificar que estás usando HTTPS
# Verificar configuración de SESSION_SECURE_COOKIE
# Verificar que TrustProxies middleware está configurado
```

### Si Mercado Pago no funciona:
```bash
# Verificar que los dominios están en el CSP
# Revisar logs: storage/logs/laravel.log
# Verificar credenciales de Mercado Pago
```

---

**Última actualización:** 17 de noviembre de 2025  
**Estado:** ✅ Listo para producción
