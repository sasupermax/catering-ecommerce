

<?php $__env->startSection('title', 'Gestión de Ofertas'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-3xl font-bold text-gray-900">Ofertas</h1>
        <a href="<?php echo e(route('admin.offers.create')); ?>" class="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition">
            ➕ Nueva Oferta
        </a>
    </div>

    <?php if(session('success')): ?>
    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <div class="bg-white rounded-lg shadow overflow-hidden">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Oferta</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Descuento</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Vigencia</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Productos</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acciones</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="px-6 py-4">
                        <div class="flex items-center">
                            <?php if($offer->image): ?>
                            <img src="<?php echo e(asset('storage/' . $offer->image)); ?>" alt="<?php echo e($offer->name); ?>" class="w-12 h-12 rounded object-cover mr-3">
                            <?php else: ?>
                            <div class="w-12 h-12 rounded bg-orange-100 flex items-center justify-center mr-3">
                                <span class="text-2xl">🎁</span>
                            </div>
                            <?php endif; ?>
                            <div>
                                <div class="font-semibold text-gray-900"><?php echo e($offer->name); ?></div>
                                <?php if($offer->description): ?>
                                <div class="text-sm text-gray-500"><?php echo e(Str::limit($offer->description, 50)); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </td>
                    <td class="px-6 py-4">
                        <span class="text-lg font-bold text-orange-600">
                            <?php if($offer->discount_type === 'percentage'): ?>
                                <?php echo e($offer->discount_value); ?>%
                            <?php else: ?>
                                $<?php echo e(number_format($offer->discount_value, 2)); ?>

                            <?php endif; ?>
                        </span>
                        <div class="text-xs text-gray-500">
                            <?php echo e($offer->discount_type === 'percentage' ? 'Porcentaje' : 'Monto fijo'); ?>

                        </div>
                        <?php if($offer->min_purchase_amount > 0): ?>
                        <div class="text-xs text-gray-500">
                            Mín: $<?php echo e(number_format($offer->min_purchase_amount, 2)); ?>

                        </div>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-sm">
                        <div><?php echo e($offer->start_date->format('d/m/Y')); ?></div>
                        <div class="text-gray-500">hasta</div>
                        <div><?php echo e($offer->end_date->format('d/m/Y')); ?></div>
                    </td>
                    <td class="px-6 py-4">
                        <span class="text-sm text-gray-600"><?php echo e($offer->products->count()); ?> productos</span>
                    </td>
                    <td class="px-6 py-4">
                        <?php if($offer->isValid()): ?>
                        <span class="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">✓ Activa</span>
                        <?php elseif($offer->is_active && $offer->start_date > now()): ?>
                        <span class="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">⏳ Próxima</span>
                        <?php elseif($offer->end_date < now()): ?>
                        <span class="px-2 py-1 text-xs rounded-full bg-gray-100 text-gray-800">⊗ Expirada</span>
                        <?php else: ?>
                        <span class="px-2 py-1 text-xs rounded-full bg-red-100 text-red-800">✕ Inactiva</span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-sm space-x-2">
                        <a href="<?php echo e(route('admin.offers.edit', $offer)); ?>" class="text-blue-600 hover:text-blue-900">Editar</a>
                        <form action="<?php echo e(route('admin.offers.destroy', $offer)); ?>" method="POST" class="inline" onsubmit="return confirm('¿Eliminar esta oferta?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:text-red-900">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-8 text-center text-gray-500">
                        No hay ofertas creadas. 
                        <a href="<?php echo e(route('admin.offers.create')); ?>" class="text-orange-600 hover:underline">Crear la primera oferta</a>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($offers->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablod\Desktop\e-commerce\resources\views/admin/offers/index.blade.php ENDPATH**/ ?>