

<?php $__env->startSection('title', $product->name . ' - Supermax Catering'); ?>

<?php $__env->startSection('content'); ?>
<!-- Breadcrumb -->
<div class="bg-gray-100 py-3">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav class="text-xs sm:text-sm overflow-x-auto whitespace-nowrap">
            <a href="<?php echo e(route('home')); ?>" class="text-red-600 hover:underline">Inicio</a>
            <span class="mx-1 sm:mx-2 text-gray-500">/</span>
            <a href="<?php echo e(route('category', $product->category->slug)); ?>" class="text-red-600 hover:underline"><?php echo e($product->category->name); ?></a>
            <span class="mx-1 sm:mx-2 text-gray-500">/</span>
            <span class="text-gray-700"><?php echo e($product->name); ?></span>
        </nav>
    </div>
</div>

<!-- Product Details -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-12">
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-12">
        <!-- Product Image -->
        <div class="order-1">
            <?php if($product->image): ?>
            <div class="w-full h-64 sm:h-80 lg:h-96 bg-gray-50 rounded-lg shadow-lg flex items-center justify-center overflow-hidden">
                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full p-5 bg-white h-full object-contain" style="view-transition-name: product-<?php echo e($product->slug); ?>;">
            </div>
            <?php else: ?>
            <div class="w-full h-64 sm:h-80 lg:h-96 bg-gradient-to-br from-gray-100 to-red-400 rounded-lg flex items-center justify-center shadow-lg">
                <span class="text-6xl sm:text-8xl lg:text-9xl">🍴</span>
            </div>
            <?php endif; ?>
        </div>

        <!-- Product Info -->
        <div class="order-2">
            <!-- <span class="text-xs sm:text-sm font-semibold text-orange-600 uppercase"><?php echo e($product->category->name); ?></span> -->
            <h1 class="text-2xl sm:text-3xl lg:text-4xl swissregular text-gray-800 mt-2"><?php echo e($product->name); ?></h1>
            
            <?php if($product->description): ?>
            <p class="text-gray-600 mt-4 text-sm sm:text-base leading-relaxed"><?php echo e($product->description); ?></p>
            <?php endif; ?>
            
            <div class="flex items-baseline mt-4 sm:mt-6">
                <span class="text-3xl sm:text-4xl swissbold text-[#d81d25]">$<?php echo e(number_format($product->price, 2)); ?></span>
                <span class="text-sm sm:text-base text-gray-600 ml-2"><?php echo e($product->price_suffix); ?></span>
            </div>
            
            <p class="text-xs text-gray-500 mt-1">
                Precio sin impuestos nacionales: $<?php echo e(number_format($product->price / 1.21, 2)); ?>

            </p>

            <!-- Order Form -->
            <div class="mt-6 sm:mt-8 bg-gray-50 rounded-lg py-4 pr-4 sm:py-6 sm:pr-6">
                <form action="<?php echo e(route('cart.add', $product)); ?>" method="POST" id="add-to-cart-form">
                    <?php echo csrf_field(); ?>
                    <div class="mb-4">
                        <label class="block text-sm sm:text-base font-semibold text-gray-700 mb-3">
                            Cantidad <?php echo e($product->type === 'P' ? '(en kg)' : '(unidades)'); ?>

                        </label>
                        <div class="flex items-center justify-between sm:justify-start sm:space-x-4">
                            <button type="button" onclick="decreaseQuantity()" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-5 sm:py-2 sm:px-4 rounded-lg text-lg sm:text-base">
                                -
                            </button>
                            <input type="number" id="quantity" name="quantity" value="1" min="<?php echo e($product->type === 'P' ? '0.5' : '1'); ?>" max="10000" step="<?php echo e($product->type === 'P' ? '0.5' : '1'); ?>" 
                                class="w-20 sm:w-24 text-center text-lg sm:text-base border-2 border-gray-300 rounded-lg py-3 sm:py-2 font-semibold" oninput="validateQuantity(this)">
                            <button type="button" onclick="increaseQuantity()" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-5 sm:py-2 sm:px-4 rounded-lg text-lg sm:text-base">
                                +
                            </button>
                        </div>
                    </div>

                    <button type="submit" id="add-to-cart-btn" class="w-full bg-[#ffd90f] text-white py-4 sm:py-3 rounded-lg text-lg font-semibold active:bg-[#e6c800] transition-all duration-500 ease-in-out shadow-lg flex items-center justify-center gap-2 transform active:scale-95">
                        <span id="btn-text" class="text-gray-700">🛒 Agregar al Carrito</span>
                        <svg id="btn-spinner" class="hidden animate-spin h-5 w-5 text-white ml-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <svg id="btn-check" class="hidden h-6 w-6 text-white ml-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7" />
                        </svg>
                    </button>
                </form>
            </div>

            <script <?php echo 'nonce="' . csp_nonce() . '"'; ?>>
                const productType = '<?php echo e($product->type); ?>';
                const step = <?php echo e($product->type === 'P' ? '0.5' : '1'); ?>;
                const minValue = <?php echo e($product->type === 'P' ? '0.5' : '1'); ?>;
                const maxValue = 10000;

                function validateQuantity(input) {
                    let value = parseFloat(input.value);
                    
                    // Prevenir valores negativos, NaN o superiores al máximo
                    if (isNaN(value) || value < minValue) {
                        input.value = minValue;
                        return;
                    }
                    if (value > maxValue) {
                        input.value = maxValue;
                        return;
                    }
                    
                    // Formatear según el tipo de producto
                    input.value = productType === 'P' ? value.toFixed(1) : Math.round(value);
                }

                function increaseQuantity() {
                    const input = document.getElementById('quantity');
                    let newValue = parseFloat(input.value) + parseFloat(step);
                    
                    if (newValue > maxValue) {
                        newValue = maxValue;
                    }
                    
                    input.value = productType === 'P' ? newValue.toFixed(1) : Math.round(newValue);
                }

                function decreaseQuantity() {
                    const input = document.getElementById('quantity');
                    let newValue = parseFloat(input.value) - parseFloat(step);
                    
                    if (newValue < minValue) {
                        newValue = minValue;
                    }
                    
                    input.value = productType === 'P' ? newValue.toFixed(1) : Math.round(newValue);
                }

                // Manejar el formulario de agregar al carrito
                document.getElementById('add-to-cart-form').addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const btn = document.getElementById('add-to-cart-btn');
                    const btnText = document.getElementById('btn-text');
                    const btnSpinner = document.getElementById('btn-spinner');
                    const btnCheck = document.getElementById('btn-check');
                    
                    // Deshabilitar el botón y mostrar spinner
                    btn.disabled = true;
                    btn.classList.remove('active:scale-95', 'active:bg-[#e6c800]');
                    btn.classList.add('cursor-not-allowed', 'opacity-75');
                    btnText.classList.add('hidden');
                    btnSpinner.classList.remove('hidden');
                    
                    // Enviar el formulario vía fetch
                    const formData = new FormData(this);
                    
                    fetch(this.action, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Ocultar spinner y mostrar check
                            btnSpinner.classList.add('hidden');
                            btnCheck.classList.remove('hidden');
                            
                            // Cambiar color del botón a verde con animación suave
                            btn.classList.remove('bg-[#ffd90f]', 'opacity-75');
                            btn.classList.add('bg-green-600');
                            btnText.textContent = 'Agregado';
                            btnText.classList.remove('hidden', 'text-gray-700');
                            btnText.classList.add('text-white');
                            
                            // Actualizar contador del carrito
                            updateCartCount();
                            
                            // Restaurar el botón después de 1.5 segundos
                            setTimeout(() => {
                                btn.disabled = false;
                                btn.classList.remove('bg-green-600', 'cursor-not-allowed');
                                btn.classList.add('bg-[#ffd90f]', 'active:scale-95', 'active:bg-[#e6c800]');
                                btnCheck.classList.add('hidden');
                                btnText.classList.remove('text-white');
                                btnText.classList.add('text-gray-700');
                                btnText.textContent = '🛒 Agregar al Carrito';
                            }, 1500);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        // Restaurar botón en caso de error
                        btn.disabled = false;
                        btn.classList.remove('cursor-not-allowed', 'opacity-75');
                        btn.classList.add('active:scale-95', 'active:bg-[#e6c800]');
                        btnSpinner.classList.add('hidden');
                        btnText.classList.remove('hidden');
                        alert('Hubo un error al agregar el producto. Por favor intenta de nuevo.');
                    });
                });

                // Función para actualizar el contador del carrito
                function updateCartCount() {
                    fetch('/carrito/count')
                        .then(res => res.json())
                        .then(data => {
                            document.querySelectorAll('.cart-count').forEach(el => {
                                el.textContent = data.count;
                            });
                        });
                }
            </script>
        </div>
    </div>

    <!-- Related Products -->
    <?php if($relatedProducts->count() > 0): ?>
    <div class="mt-12 sm:mt-16">
        <h2 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-6 sm:mb-8">Productos Relacionados</h2>
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
            <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
                <?php if($relatedProduct->image): ?>
                <img src="<?php echo e(asset('storage/' . $relatedProduct->image)); ?>" alt="<?php echo e($relatedProduct->name); ?>" class="w-full h-32 sm:h-48 p-4 object-contain bg-white" style="view-transition-name: product-<?php echo e($relatedProduct->slug); ?>;">
                <?php else: ?>
                <div class="w-full h-32 sm:h-48 bg-gradient-to-br from-gray-100 to-red-400 flex items-center justify-center">
                    <span class="text-4xl sm:text-6xl">🍴</span>
                </div>
                <?php endif; ?>
                <div class="p-3 sm:p-4">
                    <!-- <span class="text-xs font-semibold text-[#d81d25] uppercase"><?php echo e($relatedProduct->category->name); ?></span> -->
                    <h3 class="text-sm sm:text-lg font-semibold text-gray-700 mt-1 line-clamp-2"><?php echo e($relatedProduct->name); ?></h3>
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mt-3 sm:mt-4 gap-2">
                        <div>
                            <span class="text-lg sm:text-2xl swissbold text-gray-800">$<?php echo e(number_format($relatedProduct->price, 2)); ?></span>
                            <span class="text-xs text-gray-500 block sm:inline"><?php echo e($relatedProduct->price_suffix); ?></span>
                        </div>
                    </div>
                    <a href="<?php echo e(route('product', $relatedProduct->slug)); ?>" class="mt-3 block w-full bg-[#ffd90f] swissregular text-gray-800 px-3 sm:px-4 py-2 rounded-lg hover:bg-[#e2bf00] active:[#c9a700] transition text-xs sm:text-sm text-center">
                        Ver más
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablod\Desktop\e-commerce\resources\views/shop/product.blade.php ENDPATH**/ ?>