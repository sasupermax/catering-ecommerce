<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Panel de Administración'); ?> - Catering</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>
<body class="bg-gray-100" x-data>
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <aside class="w-64 bg-gray-900 text-white">
            <div class="p-6">
                <h2 class="text-2xl font-bold">🍽️ Catering Admin</h2>
                <p class="text-sm text-gray-400 mt-1"><?php echo e(auth()->user()->name); ?></p>
                <p class="text-xs text-gray-500"><?php echo e(auth()->user()->roles->pluck('name')->implode(', ')); ?></p>
            </div>

            <nav class="mt-6">
                <!-- Dashboard -->
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="flex items-center px-6 py-3 hover:bg-gray-800 <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-gray-800 border-l-4 border-orange-500' : ''); ?>">
                    <span class="mr-3">📊</span>
                    <span>Dashboard</span>
                </a>

                <!-- Pedidos (con dropdown) -->
                <?php if(auth()->user()->hasPermission('view-orders')): ?>
                <div x-data="{ open: <?php echo e(request()->routeIs('admin.orders.*') ? 'true' : 'false'); ?> }">
                    <button @click="open = !open" class="w-full flex items-center justify-between px-6 py-3 hover:bg-gray-800 <?php echo e(request()->routeIs('admin.orders.*') ? 'bg-gray-800 border-l-4 border-orange-500' : ''); ?>">
                        <div class="flex items-center">
                            <span class="mr-3">📦</span>
                            <span>Pedidos</span>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 transition-transform" :class="{'rotate-180': open}" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div x-show="open" class="bg-gray-800">
                        <a href="<?php echo e(route('admin.orders.index')); ?>" class="flex items-center px-6 py-2.5 pl-14 hover:bg-gray-700 text-sm <?php echo e(request()->routeIs('admin.orders.index') ? 'bg-gray-700' : ''); ?>">
                            <span class="mr-2">📋</span>
                            <span>Ver Todos</span>
                        </a>
                        <a href="<?php echo e(route('admin.orders.search')); ?>" class="flex items-center px-6 py-2.5 pl-14 hover:bg-gray-700 text-sm <?php echo e(request()->routeIs('admin.orders.search') ? 'bg-gray-700' : ''); ?>">
                            <span class="mr-2">🔍</span>
                            <span>Buscar Pedido</span>
                        </a>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Productos -->
                <?php if(auth()->user()->hasPermission('view-products')): ?>
                <a href="<?php echo e(route('admin.products.index')); ?>" class="flex items-center px-6 py-3 hover:bg-gray-800 <?php echo e(request()->routeIs('admin.products.*') ? 'bg-gray-800 border-l-4 border-orange-500' : ''); ?>">
                    <span class="mr-3">🍴</span>
                    <span>Productos</span>
                </a>
                <?php endif; ?>

                <!-- Categorías -->
                <?php if(auth()->user()->hasPermission('view-categories')): ?>
                <a href="<?php echo e(route('admin.categories.index')); ?>" class="flex items-center px-6 py-3 hover:bg-gray-800 <?php echo e(request()->routeIs('admin.categories.*') ? 'bg-gray-800 border-l-4 border-orange-500' : ''); ?>">
                    <span class="mr-3">📁</span>
                    <span>Categorías</span>
                </a>
                <?php endif; ?>

                <!-- Usuarios -->
                <?php if(auth()->user()->hasPermission('view-users') || auth()->user()->hasPermission('view-roles')): ?>
                <div x-data="{ open: <?php echo e(request()->routeIs('admin.users.*') || request()->routeIs('admin.roles.*') ? 'true' : 'false'); ?> }">
                    <button @click="open = !open" class="w-full flex items-center justify-between px-6 py-3 hover:bg-gray-800 <?php echo e(request()->routeIs('admin.users.*') || request()->routeIs('admin.roles.*') ? 'bg-gray-800 border-l-4 border-orange-500' : ''); ?>">
                        <div class="flex items-center">
                            <span class="mr-3">👥</span>
                            <span>Usuarios</span>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 transition-transform" :class="{'rotate-180': open}" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div x-show="open" class="bg-gray-800">
                        <?php if(auth()->user()->hasPermission('view-users')): ?>
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="flex items-center px-6 py-2.5 pl-14 hover:bg-gray-700 text-sm <?php echo e(request()->routeIs('admin.users.*') && !request()->routeIs('admin.users.roles.*') ? 'bg-gray-700' : ''); ?>">
                            <span class="mr-2">👤</span>
                            <span>Usuarios</span>
                        </a>
                        <?php endif; ?>
                        <?php if(auth()->user()->hasPermission('view-roles')): ?>
                        <a href="<?php echo e(route('admin.roles.index')); ?>" class="flex items-center px-6 py-2.5 pl-14 hover:bg-gray-700 text-sm <?php echo e(request()->routeIs('admin.roles.*') ? 'bg-gray-700' : ''); ?>">
                            <span class="mr-2">🛡️</span>
                            <span>Roles</span>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Ofertas (con dropdown) -->
                <?php if(auth()->user()->hasPermission('view-offers')): ?>
                <div x-data="{ open: <?php echo e(request()->routeIs('admin.offers.*') ? 'true' : 'false'); ?> }">
                    <button @click="open = !open" class="w-full flex items-center justify-between px-6 py-3 hover:bg-gray-800 <?php echo e(request()->routeIs('admin.offers.*') ? 'bg-gray-800 border-l-4 border-orange-500' : ''); ?>">
                        <div class="flex items-center">
                            <span class="mr-3">🎁</span>
                            <span>Ofertas</span>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 transition-transform" :class="{'rotate-180': open}" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div x-show="open" class="bg-gray-800">
                        <a href="<?php echo e(route('admin.offers.index')); ?>" class="flex items-center px-6 py-2.5 pl-14 hover:bg-gray-700 text-sm <?php echo e(request()->routeIs('admin.offers.index') ? 'bg-gray-700' : ''); ?>">
                            <span class="mr-2">📋</span>
                            <span>Ver Ofertas</span>
                        </a>
                        <?php if(auth()->user()->hasPermission('create-offers')): ?>
                        <a href="<?php echo e(route('admin.offers.create')); ?>" class="flex items-center px-6 py-2.5 pl-14 hover:bg-gray-700 text-sm <?php echo e(request()->routeIs('admin.offers.create') ? 'bg-gray-700' : ''); ?>">
                            <span class="mr-2">➕</span>
                            <span>Nueva Oferta</span>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Banners del Carousel -->
                <?php if(auth()->user()->hasPermission('view-banners')): ?>
                <div x-data="{ open: <?php echo e(request()->routeIs('admin.banners.*') ? 'true' : 'false'); ?> }">
                    <button @click="open = !open" class="w-full flex items-center justify-between px-6 py-3 hover:bg-gray-800 <?php echo e(request()->routeIs('admin.banners.*') ? 'bg-gray-800 border-l-4 border-orange-500' : ''); ?>">
                        <div class="flex items-center">
                            <span class="mr-3">🖼️</span>
                            <span>Banners</span>
                        </div>
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 transition-transform" :class="{'rotate-180': open}" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                        </svg>
                    </button>
                    <div x-show="open" class="bg-gray-800">
                        <a href="<?php echo e(route('admin.banners.index')); ?>" class="flex items-center px-6 py-2.5 pl-14 hover:bg-gray-700 text-sm <?php echo e(request()->routeIs('admin.banners.index') ? 'bg-gray-700' : ''); ?>">
                            <span class="mr-2">📋</span>
                            <span>Ver Banners</span>
                        </a>
                        <?php if(auth()->user()->hasPermission('create-banners')): ?>
                        <a href="<?php echo e(route('admin.banners.create')); ?>" class="flex items-center px-6 py-2.5 pl-14 hover:bg-gray-700 text-sm <?php echo e(request()->routeIs('admin.banners.create') ? 'bg-gray-700' : ''); ?>">
                            <span class="mr-2">➕</span>
                            <span>Nuevo Banner</span>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Configuración -->
                <?php if(auth()->user()->hasPermission('view-settings')): ?>
                <a href="<?php echo e(route('admin.settings.index')); ?>" class="flex items-center px-6 py-3 hover:bg-gray-800 <?php echo e(request()->routeIs('admin.settings.*') ? 'bg-gray-800 border-l-4 border-orange-500' : ''); ?>">
                    <span class="mr-3">⚙️</span>
                    <span>Configuración</span>
                </a>
                <?php endif; ?>

                <div class="border-t border-gray-700 my-4"></div>

                <!-- Ver Sitio -->
                <a href="<?php echo e(route('home')); ?>" target="_blank" class="flex items-center px-6 py-3 hover:bg-gray-800">
                    <span class="mr-3">🌐</span>
                    <span>Ver Sitio</span>
                </a>

                <!-- Cerrar Sesión -->
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="w-full flex items-center px-6 py-3 hover:bg-gray-800 text-left">
                        <span class="mr-3">🚪</span>
                        <span>Cerrar Sesión</span>
                    </button>
                </form>
            </nav>
        </aside>

        <!-- Main Content -->
        <div class="flex-1">
            <!-- Top Bar -->
            <header class="bg-white shadow">
                <div class="flex items-center justify-between px-8 py-4">
                    <h1 class="text-2xl font-semibold text-gray-800"><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h1>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm text-gray-600"><?php echo e(now()->format('d/m/Y H:i')); ?></span>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <main class="p-8">
                <!-- Mensajes de éxito/error -->
                <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <?php echo e(session('error')); ?>

                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\pablod\Desktop\e-commerce\resources\views/layouts/admin.blade.php ENDPATH**/ ?>