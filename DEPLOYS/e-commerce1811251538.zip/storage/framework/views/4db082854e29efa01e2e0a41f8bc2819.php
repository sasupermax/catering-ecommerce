

<?php $__env->startSection('title', 'Categorías'); ?>
<?php $__env->startSection('page-title', 'Gestión de Categorías'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 flex justify-between items-center">
    <div>
        <p class="text-gray-600">Administra las categorías de productos</p>
    </div>
    <?php if(auth()->user()->hasPermission('create-categories')): ?>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="bg-orange-600 text-white px-6 py-2 rounded-lg hover:bg-orange-700 transition">
        + Nueva Categoría
    </a>
    <?php endif; ?>
</div>

<!-- Grid de Categorías -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <?php if($category->image): ?>
        <img src="<?php echo e(asset('storage/' . $category->image)); ?>" alt="<?php echo e($category->name); ?>" class="w-full h-48 object-cover">
        <?php else: ?>
        <div class="w-full h-48 bg-gradient-to-br from-orange-400 to-red-500 flex items-center justify-center">
            <span class="text-6xl">📁</span>
        </div>
        <?php endif; ?>
        
        <div class="p-4">
            <div class="flex justify-between items-start mb-2">
                <h3 class="text-lg font-semibold text-gray-800"><?php echo e($category->name); ?></h3>
                <?php if($category->is_active): ?>
                <span class="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">
                    Activa
                </span>
                <?php else: ?>
                <span class="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-semibold">
                    Inactiva
                </span>
                <?php endif; ?>
            </div>
            
            <p class="text-gray-600 text-sm mb-3 line-clamp-2"><?php echo e($category->description); ?></p>
            
            <p class="text-gray-500 text-sm mb-4"><?php echo e($category->products_count); ?> productos</p>
            
            <div class="flex space-x-2">
                <a href="<?php echo e(route('admin.categories.show', $category)); ?>" 
                    class="flex-1 text-center px-3 py-2 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition text-sm">
                    Ver
                </a>
                
                <?php if(auth()->user()->hasPermission('edit-categories')): ?>
                <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" 
                    class="flex-1 text-center px-3 py-2 bg-orange-100 text-orange-700 rounded hover:bg-orange-200 transition text-sm">
                    Editar
                </a>
                <?php endif; ?>
                
                <?php if(auth()->user()->hasPermission('delete-categories')): ?>
                <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" 
                    onsubmit="return confirm('¿Eliminar esta categoría?');" class="flex-1">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="w-full px-3 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200 transition text-sm">
                        Eliminar
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-span-3 bg-white rounded-lg shadow p-8 text-center">
        <p class="text-gray-500">No hay categorías registradas</p>
    </div>
    <?php endif; ?>
</div>

<!-- Paginación -->
<div class="mt-6">
    <?php echo e($categories->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablod\Desktop\e-commerce\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>