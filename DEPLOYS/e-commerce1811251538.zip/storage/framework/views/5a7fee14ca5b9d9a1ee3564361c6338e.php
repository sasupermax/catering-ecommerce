

<?php $__env->startSection('title', $category->name . ' - Supermax Catering'); ?>

<?php $__env->startSection('content'); ?>
<!-- Breadcrumb -->
<div class="bg-gray-100 py-3">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <nav class="text-xs sm:text-sm overflow-x-auto whitespace-nowrap">
            <a href="<?php echo e(route('home')); ?>" class="text-red-600 hover:underline">Inicio</a>
            <span class="mx-1 sm:mx-2 text-gray-500">/</span>
            <span class="text-gray-700"><?php echo e($category->name); ?></span>
        </nav>
    </div>
</div>

<!-- Category Header -->
<div class="bg-white py-6 sm:py-8 border-b">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        <div>
            <h1 class="text-2xl sm:text-3xl lg:text-4xl swissbold text-gray-800"><?php echo e($category->name); ?></h1>
            <?php if($category->description): ?>
            <p class="text-sm sm:text-base text-gray-600 mt-2"><?php echo e($category->description); ?></p>
            <?php endif; ?>
        </div>

        <div class="flex gap-2 sm:gap-3 justify-end">
            <button id="filter-btn" class="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-1.5 sm:py-2 bg-white border-2 border-gray-300 rounded-lg hover:border-[#d81d25] transition text-xs sm:text-sm font-semibold">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 sm:h-5 sm:w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                </svg>
                Filtrar
            </button>
            <button id="sort-btn" class="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-1.5 sm:py-2 bg-white border-2 border-gray-300 rounded-lg hover:border-[#d81d25] transition text-xs sm:text-sm font-semibold">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 sm:h-5 sm:w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
                </svg>
                Ordenar
            </button>
        </div>
    </div>
</div>

<!-- Products Grid -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-12">
    <?php if($products->count() > 0): ?>
    <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
            <?php if($product->image): ?>
            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-32 sm:h-48 p-4 object-contain bg-white" style="view-transition-name: product-<?php echo e($product->slug); ?>;">
            <?php else: ?>
            <div class="w-full h-32 sm:h-48 bg-gradient-to-br from-gray-100 to-red-400 flex items-center justify-center">
                <span class="text-4xl sm:text-6xl">🍴</span>
            </div>
            <?php endif; ?>
            <div class="p-3 sm:p-4">
                    <!-- <span class="text-xs font-semibold text-[#d81d25] uppercase"><?php echo e($product->category->name); ?></span> -->
                    <h3 class="text-sm sm:text-lg font-semibold text-gray-700 mt-1 line-clamp-2"><?php echo e($product->name); ?></h3>
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mt-3 sm:mt-4 gap-2">
                        <div>
                            <span class="text-lg sm:text-2xl swissbold text-gray-800">$<?php echo e(number_format($product->price, 2)); ?></span>
                            <span class="text-xs text-gray-500 block sm:inline"><?php echo e($product->price_suffix); ?></span>
                        </div>
                    </div>
                    <a href="<?php echo e(route('product', $product->slug)); ?>" class="mt-3 block w-full bg-[#ffd90f] swissregular text-gray-800 px-3 sm:px-4 py-2 rounded-lg hover:bg-[#e2bf00] active:[#c9a700] transition text-xs sm:text-sm text-center">
                        Ver más
                    </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Pagination -->
    <div class="mt-6 sm:mt-8">
        <?php echo e($products->links()); ?>

    </div>
    <?php else: ?>
    <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-6 sm:p-8 text-center">
        <p class="text-yellow-800 text-base sm:text-lg">No hay productos disponibles en esta categoría.</p>
        <a href="<?php echo e(route('home')); ?>" class="mt-4 inline-block bg-orange-600 text-white px-6 py-2 rounded-lg hover:bg-orange-700 transition text-sm sm:text-base">
            Volver al inicio
        </a>
    </div>
    <?php endif; ?>
</div>

<!-- Filter Modal -->
<div id="filter-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
    <div class="bg-white w-full sm:w-96 sm:rounded-lg rounded-t-2xl p-6 sm:p-6 max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg sm:text-xl font-bold text-gray-800">Filtrar por precio</h3>
            <button id="close-filter" class="text-gray-500 hover:text-gray-700">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        
        <form method="GET" action="<?php echo e(route('category', $category->slug)); ?>">
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Precio mínimo</label>
                    <input type="number" name="min_price" value="<?php echo e(request('min_price')); ?>" 
                           class="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-[#d81d25] focus:outline-none" 
                           placeholder="$0" min="0" step="0.01">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">Precio máximo</label>
                    <input type="number" name="max_price" value="<?php echo e(request('max_price')); ?>" 
                           class="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-[#d81d25] focus:outline-none" 
                           placeholder="$9999" min="0" step="0.01">
                </div>
            </div>
            
            <input type="hidden" name="sort" value="<?php echo e(request('sort')); ?>">
            
            <div class="flex gap-3 mt-6">
                <button type="button" id="clear-filter" class="flex-1 px-4 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition">
                    Limpiar
                </button>
                <button type="submit" class="flex-1 px-4 py-3 bg-[#d81d25] text-white rounded-lg font-semibold hover:bg-[#c11a21] transition">
                    Aplicar
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Sort Modal -->
<div id="sort-modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
    <div class="bg-white w-full sm:w-96 sm:rounded-lg rounded-t-2xl p-6 sm:p-6 max-h-[90vh] overflow-y-auto">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg sm:text-xl font-bold text-gray-800">Ordenar por</h3>
            <button id="close-sort" class="text-gray-500 hover:text-gray-700">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        
        <form method="GET" action="<?php echo e(route('category', $category->slug)); ?>">
            <div class="space-y-2">
                <label class="flex items-center p-3 border-2 border-gray-200 rounded-lg hover:border-[#d81d25] cursor-pointer transition">
                    <input type="radio" name="sort" value="price_asc" <?php echo e(request('sort') == 'price_asc' ? 'checked' : ''); ?> class="w-4 h-4 text-[#d81d25]">
                    <span class="ml-3 text-gray-700 font-medium">Precio: Menor a Mayor</span>
                </label>
                
                <label class="flex items-center p-3 border-2 border-gray-200 rounded-lg hover:border-[#d81d25] cursor-pointer transition">
                    <input type="radio" name="sort" value="price_desc" <?php echo e(request('sort') == 'price_desc' ? 'checked' : ''); ?> class="w-4 h-4 text-[#d81d25]">
                    <span class="ml-3 text-gray-700 font-medium">Precio: Mayor a Menor</span>
                </label>
                
                <label class="flex items-center p-3 border-2 border-gray-200 rounded-lg hover:border-[#d81d25] cursor-pointer transition">
                    <input type="radio" name="sort" value="featured" <?php echo e(request('sort') == 'featured' ? 'checked' : ''); ?> class="w-4 h-4 text-[#d81d25]">
                    <span class="ml-3 text-gray-700 font-medium">Destacados</span>
                </label>
                
                <label class="flex items-center p-3 border-2 border-gray-200 rounded-lg hover:border-[#d81d25] cursor-pointer transition">
                    <input type="radio" name="sort" value="newest" <?php echo e(request('sort') == 'newest' ? 'checked' : ''); ?> class="w-4 h-4 text-[#d81d25]">
                    <span class="ml-3 text-gray-700 font-medium">Más Nuevos</span>
                </label>
                
                <label class="flex items-center p-3 border-2 border-gray-200 rounded-lg hover:border-[#d81d25] cursor-pointer transition">
                    <input type="radio" name="sort" value="oldest" <?php echo e(request('sort') == 'oldest' ? 'checked' : ''); ?> class="w-4 h-4 text-[#d81d25]">
                    <span class="ml-3 text-gray-700 font-medium">Más Antiguos</span>
                </label>
            </div>
            
            <input type="hidden" name="min_price" value="<?php echo e(request('min_price')); ?>">
            <input type="hidden" name="max_price" value="<?php echo e(request('max_price')); ?>">
            
            <button type="submit" class="w-full mt-6 px-4 py-3 bg-[#d81d25] text-white rounded-lg font-semibold hover:bg-[#c11a21] transition">
                Aplicar
            </button>
        </form>
    </div>
</div>

<script>
    // Filter Modal
    const filterBtn = document.getElementById('filter-btn');
    const filterModal = document.getElementById('filter-modal');
    const closeFilter = document.getElementById('close-filter');
    const clearFilter = document.getElementById('clear-filter');
    
    filterBtn.addEventListener('click', () => {
        filterModal.classList.remove('hidden');
    });
    
    closeFilter.addEventListener('click', () => {
        filterModal.classList.add('hidden');
    });
    
    clearFilter.addEventListener('click', () => {
        window.location.href = "<?php echo e(route('category', $category->slug)); ?>";
    });
    
    filterModal.addEventListener('click', (e) => {
        if (e.target === filterModal) {
            filterModal.classList.add('hidden');
        }
    });
    
    // Sort Modal
    const sortBtn = document.getElementById('sort-btn');
    const sortModal = document.getElementById('sort-modal');
    const closeSort = document.getElementById('close-sort');
    
    sortBtn.addEventListener('click', () => {
        sortModal.classList.remove('hidden');
    });
    
    closeSort.addEventListener('click', () => {
        sortModal.classList.add('hidden');
    });
    
    sortModal.addEventListener('click', (e) => {
        if (e.target === sortModal) {
            sortModal.classList.add('hidden');
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shop', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablod\Desktop\e-commerce\resources\views/shop/category.blade.php ENDPATH**/ ?>