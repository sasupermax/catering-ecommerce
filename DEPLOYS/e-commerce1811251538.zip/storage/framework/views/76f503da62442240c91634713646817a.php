

<?php $__env->startSection('title', 'Ver Producto'); ?>
<?php $__env->startSection('page-title', 'Detalle del Producto'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="bg-white rounded-lg shadow p-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Imagen -->
            <div>
                <?php if($product->image): ?>
                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full rounded-lg shadow">
                <?php else: ?>
                <div class="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center">
                    <span class="text-6xl">🍴</span>
                </div>
                <?php endif; ?>
            </div>

            <!-- Información -->
            <div>
                <h2 class="text-3xl font-bold text-gray-800 mb-2"><?php echo e($product->name); ?></h2>
                <p class="text-sm text-gray-600 mb-4">Categoría: <?php echo e($product->category->name); ?></p>

                <div class="mb-6">
                    <?php if($product->is_available): ?>
                    <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-semibold">
                        Disponible
                    </span>
                    <?php else: ?>
                    <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm font-semibold">
                        No disponible
                    </span>
                    <?php endif; ?>
                </div>

                <div class="space-y-4">
                    <div>
                        <p class="text-sm text-gray-600">Tipo de Producto</p>
                        <p class="text-lg font-semibold text-gray-800"><?php echo e($product->type_name); ?></p>
                    </div>

                    <div>
                        <p class="text-sm text-gray-600">Precio</p>
                        <p class="text-2xl font-bold text-orange-600">$<?php echo e(number_format($product->price, 2)); ?> <span class="text-sm text-gray-500"><?php echo e($product->price_suffix); ?></span></p>
                    </div>

                    <div>
                        <p class="text-sm text-gray-600">Pedido Mínimo</p>
                        <p class="text-lg font-semibold text-gray-800"><?php echo e($product->min_order); ?></p>
                    </div>

                    <?php if($product->description): ?>
                    <div>
                        <p class="text-sm text-gray-600 mb-2">Descripción</p>
                        <p class="text-gray-800"><?php echo e($product->description); ?></p>
                    </div>
                    <?php endif; ?>

                    <div>
                        <p class="text-sm text-gray-600">Slug</p>
                        <p class="text-gray-800 font-mono text-sm"><?php echo e($product->slug); ?></p>
                    </div>

                    <div>
                        <p class="text-sm text-gray-600">Fecha de Creación</p>
                        <p class="text-gray-800"><?php echo e($product->created_at->format('d/m/Y H:i')); ?></p>
                    </div>

                    <?php if($product->updated_at != $product->created_at): ?>
                    <div>
                        <p class="text-sm text-gray-600">Última Actualización</p>
                        <p class="text-gray-800"><?php echo e($product->updated_at->format('d/m/Y H:i')); ?></p>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Acciones -->
                <div class="mt-8 flex space-x-4">
                    <a href="<?php echo e(route('admin.products.index')); ?>" class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                        Volver
                    </a>
                    <?php if(auth()->user()->hasPermission('edit-products')): ?>
                    <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition">
                        Editar
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablod\Desktop\e-commerce\resources\views/admin/products/show.blade.php ENDPATH**/ ?>