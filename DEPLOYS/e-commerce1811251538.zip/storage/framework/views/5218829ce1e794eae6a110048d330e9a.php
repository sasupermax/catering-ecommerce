

<?php $__env->startSection('title', 'Roles'); ?>
<?php $__env->startSection('page-title', 'Gestión de Roles'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 flex justify-between items-center">
    <p class="text-gray-600">Administra los roles y permisos del sistema</p>
    <?php if(auth()->user()->hasPermission('create-roles')): ?>
    <a href="<?php echo e(route('admin.roles.create')); ?>" class="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition">
        + Crear Rol
    </a>
    <?php endif; ?>
</div>

<?php if(session('success')): ?>
<div class="mb-6 bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div class="mb-6 bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rol</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Usuarios</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Permisos</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Acciones</th>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="px-6 py-4">
                    <div>
                        <div class="text-sm font-semibold text-gray-900"><?php echo e($role->name); ?></div>
                        <div class="text-sm text-gray-500"><?php echo e($role->slug); ?></div>
                        <?php if($role->description): ?>
                        <div class="text-xs text-gray-400 mt-1"><?php echo e($role->description); ?></div>
                        <?php endif; ?>
                    </div>
                </td>
                <td class="px-6 py-4">
                    <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                        <?php echo e($role->users_count); ?> usuarios
                    </span>
                </td>
                <td class="px-6 py-4">
                    <span class="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">
                        <?php echo e($role->permissions_count); ?> permisos
                    </span>
                </td>
                <td class="px-6 py-4 text-right text-sm font-medium space-x-2">
                    <?php if(auth()->user()->hasPermission('view-roles')): ?>
                    <a href="<?php echo e(route('admin.roles.show', $role)); ?>" class="text-blue-600 hover:text-blue-900">Ver</a>
                    <?php endif; ?>
                    <?php if(auth()->user()->hasPermission('edit-roles')): ?>
                    <a href="<?php echo e(route('admin.roles.edit', $role)); ?>" class="text-orange-600 hover:text-orange-900">Editar</a>
                    <?php endif; ?>
                    <?php if(auth()->user()->hasPermission('delete-roles') && !in_array($role->slug, ['admin', 'editor', 'viewer'])): ?>
                    <form action="<?php echo e(route('admin.roles.destroy', $role)); ?>" method="POST" class="inline" onsubmit="return confirm('¿Estás seguro de eliminar este rol?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:text-red-900">Eliminar</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="px-6 py-4 text-center text-gray-500">
                    No hay roles registrados
                </td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-6">
    <?php echo e($roles->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablod\Desktop\e-commerce\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>