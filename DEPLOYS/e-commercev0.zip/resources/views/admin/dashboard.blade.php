@extends('layouts.admin')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')
<!-- Estadísticas -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
    <!-- Productos -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Productos</p>
                <p class="text-3xl font-bold text-gray-800">{{ $stats['products'] }}</p>
            </div>
            <div class="bg-blue-100 rounded-full p-4">
                <span class="text-3xl">🍴</span>
            </div>
        </div>
        @if(auth()->user()->hasPermission('view-products'))
        <a href="{{ route('admin.products.index') }}" class="text-blue-600 text-sm mt-4 inline-block hover:underline">
            Ver todos →
        </a>
        @endif
    </div>

    <!-- Categorías -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Categorías</p>
                <p class="text-3xl font-bold text-gray-800">{{ $stats['categories'] }}</p>
            </div>
            <div class="bg-green-100 rounded-full p-4">
                <span class="text-3xl">📁</span>
            </div>
        </div>
        @if(auth()->user()->hasPermission('view-categories'))
        <a href="{{ route('admin.categories.index') }}" class="text-green-600 text-sm mt-4 inline-block hover:underline">
            Ver todas →
        </a>
        @endif
    </div>

    <!-- Pedidos -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Total Pedidos</p>
                <p class="text-3xl font-bold text-gray-800">{{ $stats['orders'] }}</p>
            </div>
            <div class="bg-orange-100 rounded-full p-4">
                <span class="text-3xl">📦</span>
            </div>
        </div>
        <p class="text-orange-600 text-sm mt-4">
            {{ $stats['pendingOrders'] }} pendientes
        </p>
    </div>

    <!-- Usuarios -->
    <div class="bg-white rounded-lg shadow p-6">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-gray-500 text-sm">Usuarios</p>
                <p class="text-3xl font-bold text-gray-800">{{ $stats['users'] }}</p>
            </div>
            <div class="bg-purple-100 rounded-full p-4">
                <span class="text-3xl">👥</span>
            </div>
        </div>
        @if(auth()->user()->hasPermission('view-users'))
        <a href="{{ route('admin.users.index') }}" class="text-purple-600 text-sm mt-4 inline-block hover:underline">
            Ver todos →
        </a>
        @endif
    </div>
</div>

<!-- Accesos Rápidos -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
    <!-- Acciones Rápidas -->
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Acciones Rápidas</h3>
        <div class="space-y-3">
            @if(auth()->user()->hasPermission('create-products'))
            <a href="{{ route('admin.products.create') }}" class="flex items-center p-3 bg-blue-50 hover:bg-blue-100 rounded-lg transition">
                <span class="mr-3 text-2xl">➕</span>
                <div>
                    <p class="font-semibold text-gray-800">Nuevo Producto</p>
                    <p class="text-sm text-gray-600">Agregar producto al catálogo</p>
                </div>
            </a>
            @endif

            @if(auth()->user()->hasPermission('create-categories'))
            <a href="{{ route('admin.categories.create') }}" class="flex items-center p-3 bg-green-50 hover:bg-green-100 rounded-lg transition">
                <span class="mr-3 text-2xl">📁</span>
                <div>
                    <p class="font-semibold text-gray-800">Nueva Categoría</p>
                    <p class="text-sm text-gray-600">Crear categoría de productos</p>
                </div>
            </a>
            @endif

            @if(auth()->user()->hasPermission('create-users'))
            <a href="{{ route('admin.users.create') }}" class="flex items-center p-3 bg-purple-50 hover:bg-purple-100 rounded-lg transition">
                <span class="mr-3 text-2xl">👤</span>
                <div>
                    <p class="font-semibold text-gray-800">Nuevo Usuario</p>
                    <p class="text-sm text-gray-600">Registrar nuevo usuario</p>
                </div>
            </a>
            @endif
        </div>
    </div>

    <!-- Pedidos Recientes -->
    <div class="bg-white rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Pedidos Recientes</h3>
        @if($recentOrders->count() > 0)
        <div class="space-y-3">
            @foreach($recentOrders as $order)
            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                    <p class="font-semibold text-gray-800">#{{ $order->order_number }}</p>
                    <p class="text-sm text-gray-600">{{ $order->customer_name }}</p>
                </div>
                <div class="text-right">
                    <p class="font-semibold text-orange-600">${{ number_format($order->total, 2) }}</p>
                    <span class="text-xs px-2 py-1 rounded 
                        @if($order->status == 'pending') bg-yellow-100 text-yellow-800
                        @elseif($order->status == 'confirmed') bg-blue-100 text-blue-800
                        @elseif($order->status == 'delivered') bg-green-100 text-green-800
                        @else bg-red-100 text-red-800
                        @endif">
                        {{ ucfirst($order->status) }}
                    </span>
                </div>
            </div>
            @endforeach
        </div>
        @else
        <p class="text-gray-500 text-center py-8">No hay pedidos recientes</p>
        @endif
    </div>
</div>

<!-- Información de Permisos -->
<div class="bg-blue-50 border border-blue-200 rounded-lg p-6">
    <h3 class="text-lg font-semibold text-blue-900 mb-2">👤 Tu Rol: {{ auth()->user()->roles->first()->name ?? 'Sin rol' }}</h3>
    <p class="text-blue-700 mb-4">{{ auth()->user()->roles->first()->description ?? '' }}</p>
    
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        @foreach(auth()->user()->roles->first()->permissions ?? [] as $permission)
        <div class="bg-white rounded px-3 py-2 text-sm text-gray-700">
            ✓ {{ $permission->name }}
        </div>
        @endforeach
    </div>
</div>
@endsection
