@extends('layouts.admin')

@section('title', 'Productos')
@section('page-title', 'Gestión de Productos')

@section('content')
<div class="mb-6 flex justify-between items-center">
    <div>
        <p class="text-gray-600">Administra los productos de tu catálogo</p>
    </div>
    @if(auth()->user()->hasPermission('create-products'))
    <a href="{{ route('admin.products.create') }}" class="bg-orange-600 text-white px-6 py-2 rounded-lg hover:bg-orange-700 transition">
        + Nuevo Producto
    </a>
    @endif
</div>

<!-- Tabla de Productos -->
<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Producto</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Categoría</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Precio</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
            @forelse($products as $product)
            <tr>
                <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                        @if($product->image)
                        <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}" class="h-12 w-12 rounded object-cover">
                        @else
                        <div class="h-12 w-12 rounded bg-gray-200 flex items-center justify-center">
                            <span>🍴</span>
                        </div>
                        @endif
                        <div class="ml-4">
                            <div class="flex items-center gap-2">
                                <span class="text-sm font-medium text-gray-900">{{ $product->name }}</span>
                                @if($product->is_featured)
                                <span class="text-yellow-500" title="Producto Destacado">⭐</span>
                                @endif
                            </div>
                            <div class="text-sm text-gray-500">{{ $product->type_name }}</div>
                        </div>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="text-sm text-gray-900">{{ $product->category->name }}</span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <div>
                        <span class="text-sm font-semibold text-gray-900">${{ number_format($product->price, 2) }}</span>
                        <span class="text-xs text-gray-500">{{ $product->price_suffix }}</span>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="text-sm text-gray-900">{{ $product->stock }}</span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    @if($product->is_available)
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        Disponible
                    </span>
                    @else
                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                        No disponible
                    </span>
                    @endif
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div class="flex space-x-2">
                        <a href="{{ route('admin.products.show', $product) }}" class="text-blue-600 hover:text-blue-900">Ver</a>
                        
                        @if(auth()->user()->hasPermission('edit-products'))
                        <a href="{{ route('admin.products.edit', $product) }}" class="text-orange-600 hover:text-orange-900">Editar</a>
                        @endif
                        
                        @if(auth()->user()->hasPermission('delete-products'))
                        <form action="{{ route('admin.products.destroy', $product) }}" method="POST" class="inline" onsubmit="return confirm('¿Estás seguro de eliminar este producto?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-600 hover:text-red-900">Eliminar</button>
                        </form>
                        @endif
                    </div>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" class="px-6 py-4 text-center text-gray-500">
                    No hay productos registrados
                </td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

<!-- Paginación -->
<div class="mt-6">
    {{ $products->links() }}
</div>
@endsection
