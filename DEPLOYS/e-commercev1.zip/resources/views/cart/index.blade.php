@extends('layouts.shop')

@section('title', 'Carrito de Compras')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-12">
    <h1 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-6 sm:mb-8">Carrito de Compras</h1>

    @if(count($cartItems) > 0)
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
        <!-- Items del Carrito -->
        <div class="lg:col-span-2 space-y-4">
            @foreach($cartItems as $item)
            <div class="bg-white rounded-lg shadow-md p-4 sm:p-6" data-product-id="{{ $item['product_id'] }}">
                <div class="flex gap-3 sm:gap-4">
                    {{-- Imagen clickeable que redirige al producto --}}
                    <a href="{{ route('product', $item['product']->slug) }}" class="flex-shrink-0">
                        @if($item['product']->image)
                        <img src="{{ asset('storage/' . $item['product']->image) }}" alt="{{ $item['product']->name }}" class="w-20 h-20 sm:w-24 sm:h-24 object-cover rounded-lg hover:opacity-80 transition">
                        @else
                        <div class="w-20 h-20 sm:w-24 sm:h-24 bg-gradient-to-br from-gray-100 to-red-400 rounded-lg flex items-center justify-center hover:opacity-80 transition">
                            <span class="text-3xl">🍴</span>
                        </div>
                        @endif
                    </a>

                    <div class="flex-1 min-w-0">
                        <h3 class="text-base sm:text-lg font-semibold text-gray-800 truncate">{{ $item['product']->name }}</h3>
                        <p class="text-sm text-gray-600">{{ $item['product']->category->name }}</p>
                        
                        {{-- Mostrar subtotal del item en móvil, ocultar en desktop --}}
                        <p class="text-lg font-bold text-gray-800 mt-1 sm:hidden" id="subtotal-mobile-{{ $item['product_id'] }}">
                            ${{ number_format($item['subtotal'], 2) }}
                        </p>
                        
                        @if($item['offer'])
                        <div class="flex items-center gap-2 mt-1">
                            <span class="bg-green-100 text-green-700 text-xs px-2 py-0.5 rounded-full font-medium">
                                🎁 {{ $item['offer']->name }}
                            </span>
                        </div>
                        @endif
                        
                        {{-- Mostrar si hay una oferta disponible pero no se cumple el monto mínimo --}}
                        @php
                            $productOffer = $item['product']->getActiveOffer();
                            if (!$item['offer'] && $productOffer && !$productOffer->isApplicable(array_sum(array_map(fn($i) => $i['original_subtotal'] ?? ($i['quantity'] * $i['product']->price), $cartItems)))) {
                                $missingAmount = $productOffer->min_purchase_amount - array_sum(array_map(fn($i) => $i['original_subtotal'] ?? ($i['quantity'] * $i['product']->price), $cartItems));
                                echo '<p class="text-xs text-amber-600 mt-1">💡 Agrega $' . number_format($missingAmount, 2) . ' más para activar: ' . $productOffer->name . '</p>';
                            }
                        @endphp

                        <div class="flex items-center gap-2 sm:gap-4 mt-3">
                            <div class="flex items-center gap-1 sm:gap-2">
                                <button onclick="updateQuantity({{ $item['product_id'] }}, {{ $item['product']->type === 'P' ? '-0.5' : '-1' }})" class="bg-gray-200 hover:bg-gray-300 px-2 sm:px-3 py-1 rounded text-sm font-bold">-</button>
                                <input type="number" id="qty-{{ $item['product_id'] }}" value="{{ $item['product']->type === 'P' ? number_format($item['quantity'], 1, '.', '') : $item['quantity'] }}" step="{{ $item['product']->type === 'P' ? '0.5' : '1' }}" min="{{ $item['product']->type === 'P' ? '0.5' : '1' }}" 
                                    class="w-12 sm:w-16 text-center border border-gray-300 rounded py-1 text-sm" onchange="updateQuantityInput({{ $item['product_id'] }})">
                                <button onclick="updateQuantity({{ $item['product_id'] }}, {{ $item['product']->type === 'P' ? '0.5' : '1' }})" class="bg-gray-200 hover:bg-gray-300 px-2 sm:px-3 py-1 rounded text-sm font-bold">+</button>
                            </div>
                            <button onclick="removeItem({{ $item['product_id'] }})" class="text-red-600 hover:text-red-800 text-xs sm:text-sm font-medium flex items-center gap-1">
                                <span class="hidden sm:inline">🗑️</span> Eliminar
                            </button>
                        </div>
                    </div>

                    {{-- Subtotal solo visible en desktop --}}
                    <div class="hidden sm:block text-right flex-shrink-0">
                        <p class="text-lg sm:text-xl font-bold text-gray-800" id="subtotal-{{ $item['product_id'] }}">
                            ${{ number_format($item['subtotal'], 2) }}
                        </p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>

        <!-- Resumen -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-lg shadow-md p-6 sticky top-20">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Resumen del Pedido</h2>
                
                <div class="space-y-2 mb-4">
                    <div class="flex justify-between text-gray-600">
                        <span>Subtotal</span>
                        <span id="cart-subtotal">${{ number_format($subtotalOriginal, 2) }}</span>
                    </div>
                    
                    @if($totalDiscount > 0)
                    <div class="flex justify-between text-green-600">
                        <span>🎁 Descuentos</span>
                        <span id="cart-discount">-${{ number_format($totalDiscount, 2) }}</span>
                    </div>
                    @endif
                    
                    <div class="flex justify-between text-green-600">
                        <span>Envío</span>
                        <span>Gratis</span>
                    </div>
                </div>

                <div class="border-t pt-4 mb-6">
                    <div class="flex justify-between text-xl font-bold text-gray-800">
                        <span>Total</span>
                        <span id="cart-total-final">${{ number_format($total, 2) }}</span>
                    </div>
                </div>

                <div id="minimum-warning" class="bg-red-50 border border-red-200 rounded-lg p-4 mb-4 {{ $total >= $minOrderAmount ? 'hidden' : '' }}">
                    <p class="text-sm text-red-700">
                        <strong>⚠️ Monto mínimo no alcanzado</strong><br>
                        El monto mínimo de compra es <strong>${{ number_format($minOrderAmount, 2) }}</strong>.<br>
                        Te faltan <strong id="amount-needed">${{ number_format(max(0, $minOrderAmount - $total), 2) }}</strong>
                    </p>
                </div>
                
                <a id="checkout-btn" 
                   @if($total >= $minOrderAmount) href="{{ route('checkout.index') }}" @endif
                   class="block w-full text-center py-3 rounded-lg font-semibold transition {{ $total >= $minOrderAmount ? 'bg-orange-600 text-white hover:bg-orange-700' : 'bg-gray-300 text-gray-500 cursor-not-allowed' }}"
                   @if($total < $minOrderAmount) onclick="event.preventDefault()" @endif>
                    Continuar con el Pedido
                </a>

                <a href="{{ route('home') }}" class="block w-full text-center text-orange-600 mt-3 hover:underline">
                    Seguir Comprando
                </a>
            </div>
        </div>
    </div>
    @else
    <div class="bg-gray-50 rounded-lg p-12 text-center">
        <div class="text-6xl mb-4">🛒</div>
        <h2 class="text-2xl font-bold text-gray-800 mb-2">Tu carrito está vacío</h2>
        <p class="text-gray-600 mb-6">Agrega productos para comenzar tu pedido</p>
        <a href="{{ route('home') }}" class="inline-block bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition">
            Ver Productos
        </a>
    </div>
    @endif
</div>

<script>
const MIN_ORDER_AMOUNT = {{ $minOrderAmount }};

function updateQuantity(productId, change) {
    const input = document.getElementById(`qty-${productId}`);
    const currentQty = parseFloat(input.value);
    const step = parseFloat(input.step);
    const min = parseFloat(input.min);
    const changeValue = parseFloat(change);
    const newQty = currentQty + changeValue;

    if (newQty >= min) {
        // Si el step es 0.5 (producto por peso), usar 1 decimal, sino sin decimales
        const displayValue = (step === 0.5) ? newQty.toFixed(1) : Math.round(newQty);
        input.value = displayValue;
        saveQuantity(productId, newQty);
    }
}

function updateQuantityInput(productId) {
    const input = document.getElementById(`qty-${productId}`);
    let newQty = parseFloat(input.value);
    
    // Validar que sea un número válido
    if (isNaN(newQty) || newQty < parseFloat(input.min)) {
        newQty = parseFloat(input.min);
    }
    
    // Si el step es 0.5 (producto por peso), redondear a 1 decimal
    if (parseFloat(input.step) === 0.5) {
        newQty = Math.round(newQty * 2) / 2; // Redondear a .0 o .5
        input.value = newQty.toFixed(1);
    } else {
        newQty = Math.round(newQty);
        input.value = newQty;
    }
    
    saveQuantity(productId, newQty);
}

function saveQuantity(productId, quantity) {
    fetch('/carrito/actualizar', {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify({ product_id: productId, quantity: quantity })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            // Si hay ofertas fijas que afectan el total, recargar la página
            if (data.reload) {
                location.reload();
                return;
            }
            
            // Actualizar subtotal en desktop
            const desktopSubtotal = document.getElementById(`subtotal-${productId}`);
            if (desktopSubtotal) {
                desktopSubtotal.textContent = `$${data.subtotal.toFixed(2)}`;
            }
            
            // Actualizar subtotal en móvil
            const mobileSubtotal = document.getElementById(`subtotal-mobile-${productId}`);
            if (mobileSubtotal) {
                mobileSubtotal.textContent = `$${data.subtotal.toFixed(2)}`;
            }
            
            document.getElementById('cart-total').textContent = `$${data.total.toFixed(2)}`;
            document.getElementById('cart-total-final').textContent = `$${data.total.toFixed(2)}`;
            updateCartCount();
            checkMinimumAmount(data.total);
        }
    });
}

function checkMinimumAmount(total) {
    const minimumWarning = document.getElementById('minimum-warning');
    const amountNeeded = document.getElementById('amount-needed');
    const checkoutBtn = document.getElementById('checkout-btn');
    
    if (total < MIN_ORDER_AMOUNT) {
        // Mostrar advertencia
        minimumWarning.classList.remove('hidden');
        const needed = MIN_ORDER_AMOUNT - total;
        amountNeeded.textContent = `$${needed.toFixed(2)}`;
        
        // Deshabilitar botón (quitar href para que no sea clickeable)
        checkoutBtn.removeAttribute('href');
        checkoutBtn.onclick = (e) => e.preventDefault();
        checkoutBtn.className = 'block w-full bg-gray-300 text-gray-500 text-center py-3 rounded-lg font-semibold cursor-not-allowed';
        checkoutBtn.textContent = 'Continuar con el Pedido';
    } else {
        // Ocultar advertencia
        minimumWarning.classList.add('hidden');
        
        // Habilitar botón (agregar href para que funcione el enlace)
        checkoutBtn.setAttribute('href', '{{ route('checkout.index') }}');
        checkoutBtn.onclick = null;
        checkoutBtn.className = 'block w-full bg-orange-600 text-white text-center py-3 rounded-lg font-semibold hover:bg-orange-700 transition';
        checkoutBtn.textContent = 'Continuar con el Pedido';
    }
}

function removeItem(productId) {
    if (!confirm('¿Eliminar este producto del carrito?')) return;

    fetch(`/carrito/remover/${productId}`, {
        method: 'DELETE',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        }
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    });
}

function updateCartCount() {
    fetch('/carrito/count')
        .then(res => res.json())
        .then(data => {
            document.querySelectorAll('.cart-count').forEach(el => {
                el.textContent = data.count;
            });
        });
}
</script>
@endsection
