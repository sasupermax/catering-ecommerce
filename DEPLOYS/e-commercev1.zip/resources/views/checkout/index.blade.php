@extends('layouts.shop')

@section('title', 'Finalizar Pedido')

@section('content')
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-12">
    <!-- Breadcrumb -->
    <div class="mb-6 sm:mb-8">
        <nav class="text-xs sm:text-sm text-gray-600">
            <a href="{{ route('home') }}" class="hover:text-orange-600">Inicio</a>
            <span class="mx-2">/</span>
            <a href="{{ route('cart.index') }}" class="hover:text-orange-600">Carrito</a>
            <span class="mx-2">/</span>
            <span class="text-gray-900 font-semibold">Checkout</span>
        </nav>
    </div>

    <h1 class="text-2xl sm:text-3xl font-bold text-gray-800 mb-6 sm:mb-8">Finalizar Pedido</h1>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
        <!-- Formulario de Datos -->
        <div class="lg:col-span-2">
            <form action="{{ route('checkout.process') }}" method="POST" class="space-y-6">
                @csrf

                <!-- Datos de Contacto -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">📧 Datos de Contacto</h2>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Nombre Completo *</label>
                            <input type="text" name="customer_name" value="{{ old('customer_name') }}" required
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                            @error('customer_name')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                                <input type="email" name="customer_email" value="{{ old('customer_email') }}" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                                @error('customer_email')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Teléfono *</label>
                                <input type="tel" name="customer_phone" value="{{ old('customer_phone') }}" required
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                                @error('customer_phone')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                                @enderror
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Datos de Entrega -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-xl font-bold text-gray-800 mb-4">🚚 Datos de Entrega</h2>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Dirección de Entrega *</label>
                            <input type="text" name="delivery_address" value="{{ old('delivery_address') }}" required
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                placeholder="Ej: Calle 123, Ciudad">
                            @error('delivery_address')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Fecha de Entrega *</label>
                            <input type="date" id="delivery_date" name="delivery_date" value="{{ old('delivery_date') }}" required
                                min="{{ $minDate->format('Y-m-d') }}"
                                max="{{ $maxDate->format('Y-m-d') }}"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent">
                            <p id="fecha-info" class="text-xs text-gray-500 mt-1">Solo puedes elegir fechas disponibles ({{ $minDate->format('d/m/Y') }} - {{ $maxDate->format('d/m/Y') }})</p>
                            <p id="fecha-error" class="text-red-500 text-xs mt-1 hidden"></p>
                            @error('delivery_date')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Notas Adicionales</label>
                            <textarea name="notes" rows="3"
                                class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                placeholder="Instrucciones especiales, referencias, etc.">{{ old('notes') }}</textarea>
                        </div>
                    </div>
                </div>

                <div class="flex flex-col sm:flex-row gap-4">
                    <a href="{{ route('cart.index') }}" class="flex-1 bg-gray-200 text-gray-700 text-center py-3 rounded-lg font-semibold hover:bg-gray-300 transition">
                        ← Volver al Carrito
                    </a>
                    <button type="submit" class="flex-1 bg-orange-600 text-white py-3 rounded-lg font-semibold hover:bg-orange-700 transition">
                        Continuar al Pago →
                    </button>
                </div>
            </form>
        </div>

        <!-- Resumen del Pedido -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-lg shadow-md p-6 sticky top-20">
                <h2 class="text-xl font-bold text-gray-800 mb-4">Resumen del Pedido</h2>
                
                <div class="space-y-3 mb-4 max-h-64 overflow-y-auto">
                    @foreach($cartItems as $item)
                    <div class="flex justify-between text-sm">
                        <div class="flex-1">
                            <p class="font-medium text-gray-800">{{ $item['name'] }}</p>
                            <p class="text-gray-600">{{ $item['quantity'] }} {{ $item['type'] === 'P' ? 'kg' : 'ud' }} × ${{ number_format($item['price'], 2) }}</p>
                        </div>
                        <p class="font-semibold text-gray-800">${{ number_format($item['subtotal'], 2) }}</p>
                    </div>
                    @endforeach
                </div>

                <div class="border-t pt-4 space-y-2">
                    <div class="flex justify-between text-gray-600">
                        <span>Subtotal</span>
                        <span>${{ number_format($subtotal, 2) }}</span>
                    </div>
                    <div class="flex justify-between text-green-600">
                        <span>Envío</span>
                        <span>Gratis</span>
                    </div>
                    <div class="flex justify-between text-xl font-bold text-gray-800 pt-2 border-t">
                        <span>Total</span>
                        <span>${{ number_format($subtotal, 2) }}</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', async function() {
    let deliverySettings = null;
    
    try {
        const response = await fetch('/api/delivery/available-dates');
        if (response.ok) {
            deliverySettings = await response.json();
            
            const fechaInput = document.getElementById('delivery_date');
            const fechaInfo = document.getElementById('fecha-info');
            
            if (fechaInput) {
                fechaInput.min = deliverySettings.minDate;
                fechaInput.max = deliverySettings.maxDate;
                
                if (fechaInfo) {
                    const minDateFormatted = new Date(deliverySettings.minDate).toLocaleDateString('es-AR');
                    const maxDateFormatted = new Date(deliverySettings.maxDate).toLocaleDateString('es-AR');
                    fechaInfo.textContent = `Selecciona una fecha entre ${minDateFormatted} y ${maxDateFormatted}`;
                }
                
                // Validar fecha seleccionada
                fechaInput.addEventListener('change', (e) => {
                    const fechaSeleccionada = e.target.value;
                    const fechaError = document.getElementById('fecha-error');
                    
                    if (!fechaSeleccionada) {
                        return;
                    }
                    
                    // Verificar si la fecha está en el rango
                    if (fechaSeleccionada < deliverySettings.minDate || fechaSeleccionada > deliverySettings.maxDate) {
                        fechaError.textContent = 'La fecha seleccionada está fuera del rango permitido';
                        fechaError.classList.remove('hidden');
                        fechaInput.value = '';
                        return;
                    }
                    
                    // Verificar si la fecha ya alcanzó el límite de pedidos
                    const pedidosEnFecha = deliverySettings.occupiedDates[fechaSeleccionada] || 0;
                    if (pedidosEnFecha >= deliverySettings.maxOrdersPerDay) {
                        fechaError.textContent = `Esta fecha ya alcanzó el límite de ${deliverySettings.maxOrdersPerDay} pedidos. Por favor, selecciona otra fecha.`;
                        fechaError.classList.remove('hidden');
                        fechaInput.value = '';
                        return;
                    }
                    
                    // Fecha válida
                    fechaError.classList.add('hidden');
                });
            }
        }
    } catch (error) {
        console.error('Error al cargar configuración de entregas:', error);
    }
});
</script>

@endsection
