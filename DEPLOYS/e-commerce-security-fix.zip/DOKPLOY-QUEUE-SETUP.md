# 🚀 Configuración de Queue Worker en Dokploy con Supervisor

## Resumen

Para que los emails se envíen automáticamente en producción, usaremos **Supervisor** que mantiene el worker corriendo permanentemente y lo reinicia automáticamente si falla.

---

## 📋 Configuración Paso a Paso

### Paso 1: El archivo ya está creado ✅

El archivo `supervisor.conf` ya está en la raíz del proyecto con la configuración correcta.

### Paso 2: Configurar en Dokploy

1. **Ve a tu aplicación en Dokploy**
2. **Settings → Advanced**
3. **Busca la sección de Supervisor o Post-deploy scripts**
4. **Agrega el siguiente comando** en los scripts de post-deploy:

```bash
# Copiar configuración de supervisor
cp /app/supervisor.conf /etc/supervisor/conf.d/laravel-worker.conf

# Recargar supervisor
supervisorctl reread
supervisorctl update
supervisorctl start laravel-worker:*
```

### Paso 3: Variables de entorno

Asegúrate de tener estas variables en Dokploy:

```env
QUEUE_CONNECTION=database
MAIL_MAILER=smtp
MAIL_HOST=smtp-mail.outlook.com
MAIL_PORT=587
MAIL_USERNAME=tu-email@outlook.com
MAIL_PASSWORD=tu-contraseña
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="tu-email@outlook.com"
MAIL_FROM_NAME="SUPERMAX Catering"
```

### Paso 4: Redeploy

Haz un nuevo deploy para aplicar los cambios.

### Verificar que funciona

Ejecuta en la consola de Dokploy:

```bash
# Ver estado del worker
supervisorctl status

# Ver logs del worker
tail -f /app/storage/logs/worker.log
```

---

## 📊 Verificar que funciona

### 1. Crear un pedido de prueba

1. Crea un pedido en la aplicación
2. Espera 1-2 minutos (dependiendo del método)
3. Verifica tu email

### 2. Ver logs

```bash
# Logs de Laravel (incluye queue)
tail -f /app/storage/logs/laravel.log

# Logs del worker de Supervisor
tail -f /app/storage/logs/worker.log

# Ver tabla de jobs pendientes
php artisan tinker
DB::table('jobs')->count()
DB::table('jobs')->get()
exit
```

### 3. Verificar jobs fallidos

```bash
# Ver jobs que fallaron
php artisan queue:failed

# Reintentar jobs fallidos
php artisan queue:retry all
```

---

## 🐛 Troubleshooting

### Los emails no se envían

**1. Verifica que el queue worker esté corriendo:**

```bash
# Ver estado del supervisor
supervisorctl status
```

**2. Verifica las credenciales de email:**

```bash
# Probar conexión SMTP
php artisan tinker
Mail::raw('Test', function($msg) { $msg->to('test@example.com')->subject('Test'); });
```

**3. Revisa los logs:**

```bash
tail -f /app/storage/logs/laravel.log | grep -i mail
```

### Error de permisos

```bash
# Dar permisos a logs
chown -R www-data:www-data /app/storage
chmod -R 775 /app/storage
```

### Worker no inicia (Supervisor)

```bash
# Ver error específico
supervisorctl tail laravel-worker stderr

# Reiniciar manualmente
supervisorctl restart laravel-worker:*
```

---

## 📝 Comandos útiles

```bash
# Ver jobs en cola
php artisan queue:monitor

# Limpiar jobs fallidos
php artisan queue:flush

# Reintentar jobs fallidos
php artisan queue:retry all

# Procesar 1 job manualmente
php artisan queue:work --once

# Ver configuración de scheduler
php artisan schedule:list
```

---

## 🔒 Seguridad en Producción

### Variables de entorno sensibles

**NO subas al repositorio:**
- `MAIL_PASSWORD`
- `MERCADOPAGO_ACCESS_TOKEN`

**Configúralas directamente en Dokploy:**
Settings → Environment Variables

### Logs

Los logs de worker van a `/app/storage/logs/worker.log`

Rotar logs para evitar que crezcan demasiado:

```bash
# En cron jobs de Dokploy, agrega:
0 0 * * * find /app/storage/logs -name "*.log" -size +50M -delete
```

---

## ✨ Resultado Final

Con cualquiera de las dos opciones:

✅ Los emails se envían automáticamente  
✅ El sistema es resiliente (reintentos automáticos)  
✅ No bloquea la experiencia del usuario  
✅ Los logs se guardan para debugging  

---

## 📞 Soporte

Si tienes problemas:

1. Revisa los logs: `storage/logs/laravel.log`
2. Verifica las variables de entorno en Dokploy
3. Prueba enviar un email manualmente: `php artisan email:test created`
4. Verifica que el worker esté corriendo

---

**¿Necesitas ayuda adicional? Revisa los logs primero y luego consulta con el equipo de desarrollo.**
